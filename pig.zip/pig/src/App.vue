<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
/*整个页面的背景色*/
body{
  background-color: #f5f5f5;
  min-width:1000px;
}
/*一级容器定宽居中*/
body>.container{
  width:1200px;
  min-width:1200px;
  margin:0 auto;
}
*{margin: 0;padding: 0;}
body{
    background-color: #f5f5ff;
    color: #333;
    font:14px/1.5 Hiragino Sans GB,Microsoft Yahei UI,Microsoft Yahei,微软雅黑,Segoe UI,Tahoma,宋体b8b\\4f53,SimSun,sans-serif ;
}
a{
    color:#fff;
    text-decoration:none;
}
a:hover{
    text-decoration:none;
    color: #fed243;
}
.my-color{
    color: #333;
}
ul,ol{list-style: none;}
</style>
