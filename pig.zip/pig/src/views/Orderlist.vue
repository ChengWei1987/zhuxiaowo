<template>
    <div>
        <!-- 引入头组件信息 -->
        <my-header></my-header>
    </div>
</template>