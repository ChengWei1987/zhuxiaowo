#设置客户端连接服务器端的编码为UTF8
SET NAMES UTF8;
#丢弃数据库zhuxiaowo，如果存在的话
DROP DATABASE IF EXISTS zhuxiaowo;
#创建一个新的数据库zhuxiaowo，设置存储的编码为UTF8
CREATE DATABASE zhuxiaowo CHARSET=UTF8;
#进入刚刚创建的数据库zhuxiaowo
USE zhuxiaowo;
#创建保存用户数据的表user
CREATE TABLE user(
  iid INT PRIMARY KEY AUTO_INCREMENT,
  uname VARCHAR(16) NOT NULL,
  upwd VARCHAR(32),
  birthday DATE,
  phone VARCHAR(11),
  email VARCHAR(32),
  sex VARCHAR(1)  # 1->男  0->女
);
#插入用户数据
INSERT INTO user VALUES(1,'猪猪','123456','1998-6-12','18112345678','ding@163.com','1');
INSERT INTO user VALUES(NULL,'猪小窝','123456','1994-9-17','18812345678','dang@qq.com','0');
INSERT INTO user VALUES(NULL,'亮亮','123456','1989-5-23','17812345678','dong@sina.com','1');

#创建房源信息表
CREATE TABLE house(
  #房子编号
  hid INT PRIMARY KEY AUTO_INCREMENT,
  #建筑类型
  housetypes VARCHAR(8),
  #物业费用
  price DECIMAL(7,2),
  #物业公司
  manage VARCHAR(16),
  #开发商
  maker VARCHAR(16),
  #楼栋层数
  floors TINYINT,
  #房屋总数
  housequantity INT,
  #附近门店
  nearbyshop VARCHAR(128)
);
INSERT INTO house VALUES(0001,'塔楼','1400.00','猪小窝地产集团','小飞猪','40','400','万达广场,地铁站');
INSERT INTO house VALUES(NULL,'渔村','1200.00','猪小窝地产集团','小飞猪','40','400','万达广场,地铁站');
INSERT INTO house VALUES(NULL,'靶场','1600.00','猪小窝地产集团','小飞猪','50','400','润科华府,地铁站');
INSERT INTO house VALUES(NULL,'靶场','1200.00','猪小窝地产集团','小飞猪','30','400','桃源居,地铁站');
INSERT INTO house VALUES(NULL,'渔村','1600.00','猪小窝地产集团','小飞猪','55','400','万达广场,地铁站');
INSERT INTO house VALUES(NULL,'塔楼','1200.00','猪小窝地产集团','小飞猪','60','400','松日鼎盛,地铁站');
INSERT INTO house VALUES(NULL,'靶场','1600.00','猪小窝地产集团','小飞猪','46','400','万达广场,公交站');
INSERT INTO house VALUES(NULL,'靶场','1200.00','猪小窝地产集团','小飞猪','27','400','万利达广场,地铁站');
INSERT INTO house VALUES(NULL,'塔楼','1600.00','猪小窝地产集团','小飞猪','40','400','揽水路万达广场,八楼');
INSERT INTO house VALUES(NULL,'塔楼','1200.00','猪小窝地产集团','小飞猪','60','400','腾讯总部,地铁站');
INSERT INTO house VALUES(NULL,'靶场','1600.00','猪小窝地产集团','小飞猪','40','400','枫山红,公交站');
INSERT INTO house VALUES(NULL,'塔楼','1200.00','猪小窝地产集团','小飞猪','40','400','绿地集团,公交站');
INSERT INTO house VALUES(NULL,'渔村','1600.00','猪小窝地产集团','小飞猪','50','400','墨水湖,地铁站');
INSERT INTO house VALUES(NULL,'塔楼','1500.00','猪小窝地产集团','小飞猪','55','400','汉阳铜炉造,接驳站');
INSERT INTO house VALUES(NULL,'靶场','1600.00','猪小窝地产集团','小飞猪','40','400','洪山广场,地铁站');
INSERT INTO house VALUES(NULL,'渔村','1200.00','猪小窝地产集团','小飞猪','45','400','小龟山,地铁站');
INSERT INTO house VALUES(NULL,'塔楼','1600.00','猪小窝地产集团','小飞猪','40','400','积木桥,地铁站');
INSERT INTO house VALUES(NULL,'渔村','1200.00','猪小窝地产集团','小飞猪','45','400','沌口,地铁站');
INSERT INTO house VALUES(NULL,'塔楼','1600.00','猪小窝地产集团','小飞猪','40','400','鹤洲桥底,公交站');
INSERT INTO house VALUES(NULL,'塔楼','1200.00','猪小窝地产集团','小飞猪','51','400','望牛亭,公交站站');
INSERT INTO house VALUES(NULL,'靶场','1600.00','猪小窝地产集团','小飞猪','40','400','立新湖,地铁站');
INSERT INTO house VALUES(NULL,'塔楼','1200.00','猪小窝地产集团','小飞猪','52','400','万达广场,地铁站');
INSERT INTO house VALUES(NULL,'渔村','1600.00','猪小窝地产集团','小飞猪','40','400','万达广场,地铁站');
INSERT INTO house VALUES(NULL,'塔楼','1400.00','猪小窝地产集团','小飞猪','40','400','万达广场,地铁站');
INSERT INTO house VALUES(NULL,'渔村','1200.00','猪小窝地产集团','小飞猪','40','400','万达广场,地铁站');
INSERT INTO house VALUES(NULL,'靶场','1600.00','猪小窝地产集团','小飞猪','50','400','润科华府,地铁站');
INSERT INTO house VALUES(NULL,'靶场','1200.00','猪小窝地产集团','小飞猪','30','400','桃源居,地铁站');
INSERT INTO house VALUES(NULL,'渔村','1600.00','猪小窝地产集团','小飞猪','55','400','万达广场,地铁站');
INSERT INTO house VALUES(NULL,'塔楼','1200.00','猪小窝地产集团','小飞猪','60','400','松日鼎盛,地铁站');
INSERT INTO house VALUES(NULL,'靶场','1600.00','猪小窝地产集团','小飞猪','46','400','万达广场,公交站');
INSERT INTO house VALUES(NULL,'靶场','1200.00','猪小窝地产集团','小飞猪','27','400','万利达广场,地铁站');
INSERT INTO house VALUES(NULL,'塔楼','1600.00','猪小窝地产集团','小飞猪','40','400','揽水路万达广场,八楼');
INSERT INTO house VALUES(NULL,'塔楼','1200.00','猪小窝地产集团','小飞猪','60','400','腾讯总部,地铁站');
INSERT INTO house VALUES(NULL,'靶场','1600.00','猪小窝地产集团','小飞猪','40','400','枫山红,公交站');
INSERT INTO house VALUES(NULL,'塔楼','1200.00','猪小窝地产集团','小飞猪','40','400','绿地集团,公交站');
INSERT INTO house VALUES(NULL,'渔村','1600.00','猪小窝地产集团','小飞猪','50','400','墨水湖,地铁站');
INSERT INTO house VALUES(NULL,'塔楼','1500.00','猪小窝地产集团','小飞猪','55','400','汉阳铜炉造,接驳站');
INSERT INTO house VALUES(NULL,'靶场','1600.00','猪小窝地产集团','小飞猪','40','400','洪山广场,地铁站');
INSERT INTO house VALUES(NULL,'渔村','1200.00','猪小窝地产集团','小飞猪','45','400','小龟山,地铁站');
INSERT INTO house VALUES(NULL,'塔楼','1600.00','猪小窝地产集团','小飞猪','40','400','积木桥,地铁站');
INSERT INTO house VALUES(NULL,'渔村','1200.00','猪小窝地产集团','小飞猪','45','400','沌口,地铁站');
INSERT INTO house VALUES(NULL,'塔楼','1600.00','猪小窝地产集团','小飞猪','40','400','鹤洲桥底,公交站');
INSERT INTO house VALUES(NULL,'塔楼','1200.00','猪小窝地产集团','小飞猪','51','400','望牛亭,公交站站');
INSERT INTO house VALUES(NULL,'靶场','1600.00','猪小窝地产集团','小飞猪','40','400','立新湖,地铁站');
INSERT INTO house VALUES(NULL,'塔楼','1200.00','猪小窝地产集团','小飞猪','52','400','万达广场,地铁站');
INSERT INTO house VALUES(NULL,'渔村','1600.00','猪小窝地产集团','小飞猪','40','400','万达广场,地铁站');

#创建用户订单表
CREATE TABLE user_Order(
  #订单编号
  hid INT PRIMARY KEY AUTO_INCREMENT,
  #订单时间
  adddate INT,
  #用户
  userId INT,
  FOREIGN KEY(userId) REFERENCES user(iid),
  #房源
  houseId INT,
  FOREIGN KEY(houseId) REFERENCES house(hid)
);

INSERT INTO user_Order VALUES(0001,156786238468,1,0001);
INSERT INTO user_Order VALUES(NULL,156786568461,2,0002);
INSERT INTO user_Order VALUES(NULL,156713841646,3,0003);