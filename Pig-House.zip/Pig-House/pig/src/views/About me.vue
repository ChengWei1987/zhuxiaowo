<template>
  <div>
    <!-- 引入头组件信息 -->
    <my-header></my-header>
    <div class="container">
      	<div id="demo" class="carousel " data-ride="carousel">
				<!-- 1.要轮播的图片 -->
				<div class="carousel-inner">
					<div class="carousel-item active">
						<img class="w-100" src="../../public/img/banner1.jpg" >
					</div>
					<div class="carousel-item">
						<img class="w-100" src="../../public/img/banner2.png" >
					</div>
					<div class="carousel-item">
						<img class="w-100" src="../../public/img/banner3.jpg" >
					</div>
				</div>
				<!-- 2.轮播指示器 -->
				<ul class="carousel-indicators">
					<li data-target="#demo" data-slide-to="0" class="active"></li>
					<li data-target="#demo" data-slide-to="1"></li>
					<li data-target="#demo" data-slide-to="2"></li>
				</ul>
				<!-- 3.左右箭头 -->
				<a data-slide="prev" href="#demo" class="carousel-control-prev" >
					<span class="carousel-control-prev-icon"></span>
				</a>
				<a data-slide="next" href="#demo" class="carousel-control-next" >
					<span class="carousel-control-next-icon"></span>
				</a>
		</div>
      <div class="main">
		<!-- 公司简介 -->
        <ul>
			<li class="w-50">
				<p class="h2 mb-3">公司介绍</p>
				<span>深圳猪小窝房屋管理平台（简称：猪小窝）成立于2019年底，在日新月异的快速发展中得到了源渡创投、君联资本、经纬中国、海纳百川等国际国内一线投资机构的注资。小窝依托先进的互联网技术及创新的金融工具为两类客户提供服务：对闲置房业主，提供一站式房屋租赁增值管理解决方案；为城市租房人群，提供高品质长租公寓产品、租后服务，以及围绕房屋、居住社交而衍生的增值服务。公司目前在成都、武汉、北京、杭州、深圳、珠海和湛江等地发展，累计管理房屋数近300000间，为15000+业主，90000+优质租客提供过服务。</span>
		  	</li>
			<li class="w-45">
				<div id="demo1" class="carousel mt-5 ml-4" data-ride="carousel">
					<!-- 1.要轮播的图片 -->
					<div class="carousel-inner">
						<div class="carousel-item active">
							<img class="w-100" src="../../public/img/small_banner1.jpg" >
						</div>
						<div class="carousel-item">
							<img class="w-100" src="../../public/img/small_banner2.jpg" >
						</div>
						<div class="carousel-item">
							<img class="w-100" src="../../public/img/small_banner3.jpg" >
						</div>
					</div>
					<!-- 2.左右箭头 -->
					<a data-slide="prev" href="#demo1" class="carousel-control-prev" >
						<span class="carousel-control-prev-icon"></span>
					</a>
					<a data-slide="next" href="#demo1" class="carousel-control-next" >
						<span class="carousel-control-next-icon"></span>
					</a>
				</div>
			</li>
        </ul>
		<!-- 新闻中心 -->
		<div class="news w-50 ">
			<p class="h2 mt-3 mb-3 text-right">新闻中心</p>

		</div>
      </div>
    </div>
	
  </div>
</template>

<style scoped>
	.main{position:relative;}
    .main p{color:grey;text-align: left;border-bottom: 2px solid ;}
    .main span{color:#000;text-align: left;text-indent:40px ;font-size: 14px;display: block;line-height: 36px;}
	.news{position: absolute;right:0;margin-top:18rem}
	.w-45{width:45%}
	ul>li{float: left;}
</style>
