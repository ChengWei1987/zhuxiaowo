<template>
  <div>
    <my-header></my-header>
    <div class="container-fluid" >
        <!--轮播图 -->
        <div  class="carousel" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active" data-interval="100">
                    <img  src="/img/index/lunbo-1.jpg" >                 
                </div>
                <div class="carousel-item">
                    <img  src="/img/index/lunbo-2.jpg">                    
                </div>
                <div class="carousel-item">
                    <img  src="/img/index/lunbo-3.jpg" >
                </div>
            </div>
        </div>
        <div class="container">
        <!-- 导航栏 -->
                <ul class="menu list-unstyled d-flex justify-content-between"> 
                    <li><a href="">首页</a></li>
                    <li>二手房
                        <ul class="list-unstyled">
                            <li><a href="">房源列表</a></li>
                            <li><a href="">小区列表</a></li>
                        </ul>
                    </li>
                    <li>新房
                        <ul>
                            <li><a href="">新房首页</a></li>
                            <li><a href="">房源列表</a></li>
                        </ul>
                    </li>
                    <li>租房
                        <ul>
                            <li><a href="">房源列表</a></li>
                            <li><a href="">小区列表</a></li>
                        </ul>
                    </li>
                    <li><a href="">登入</a> | <a href="">注册</a></li>
                </ul> 
            <!-- 搜索区 -->
                <div class="seach">
                    <ul class="d-flex list-unstyled ml-5 mt-4">
                        <li class="mr-5">二手房</li>
                        <li class="mr-5">新房</li>
                        <li class="mr-5">租房</li>
                        <li class="mr-5">小区</li>
                        <li>写字楼</li>
                    </ul>
                    <div class="ml-5 mt-4 d-flex">
                        <input class="form-control text-muted w-75" type="text" maxlength="40" placeholder="请输入房源特征、房型、小区名...">
                        <button class="btn btn-warning mb-2"><img src="/img/index/sousuo.png" alt=""></button>
                    </div>
                </div>  
        </div>
    </div>
    <div class="container mt-3">
        <div class="row no-gutters text-center ">
            <div class="col-3 entrances ">
                <a href=""><img src="/img/index/ershoufang.png" >
                    <p>二手房</p>
                </a> 
            </div>
            <div class="col-3 entrances">
                <a href=""><img src="/img/index/xinfang.png" >
                    <p>新房</p>
                </a>  
            </div>
            <div class="col-3 entrances">
                <a href=""><img src="/img/index/hanglixiang.png" >
                    <p>租房</p>
                </a>  
            </div>
            <div class="col-3 entrances">
                <a href=""><img src="/img/index/maifang.png" >
                    <p>卖房·出租</p>
                </a>  
            </div>
        </div>
        <!-- f1 二手房 -->
        <div class="f1 mt-5">
            <h3>二手好房为你而选</h3>
            <div class="d-flex justify-content-between my-3">
                <p class="text-muted">好房源那么多，我们为你精选，猪小窝会越来越懂你</p>
                <a href="javascript:;" class="my-color">更多深圳二手房</a>
            </div>    
            <ul class="list-unstyled d-flex justify-content-between">
                <li class="items">
                    <a href="javascript:;">
                        <div >
                            <img  src="img/index/ef-1.jpg">
                        </div>
                        <div class="price bg-dark ">520万</div>
                        <div class="px-3">
                            <div class="d-flex justify-content-between mt-4 "  >
                                <h5 class="my-color">水湾小区</h5><p class="text-muted ">南山-蛇口</p>
                            </div>
                            <p class="mb-4 my-color">4室2厅73.13平米</p>
                        </div>
                    </a>
                </li>
                <li class="items">
                    <a href="javascript:;">
                        <div >
                            <img  src="img/index/ef-2.jpg">
                        </div>
                        <div class="price bg-dark ">680万</div>
                        <div class="px-3">
                            <div class="d-flex justify-content-between mt-4 "  >
                                <h5 class="my-color">嘉湖新都</h5><p class="text-muted ">罗湖-翠竹</p>
                            </div>
                            <p class="mb-4 my-color">3室2 81.98平米</p>
                        </div>
                    </a>
                </li>
                <li class="items">
                    <a href="javascript:;">
                        <div >
                            <img  src="img/index/ef-3.jpg">
                        </div>
                        <div class="price bg-dark ">720万</div>
                        <div class="px-3">
                            <div class="d-flex justify-content-between mt-4 "  >
                                <h5 class="my-color">君荟</h5><p class="text-muted ">罗湖-东门</p>
                            </div>
                            <p class="mb-4 my-color">3室2厅87.46平米</p>
                        </div>
                    </a>
                </li>
                <li class="items">
                    <a href="javascript:;">
                        <div >
                            <img  src="img/index/ef-4.jpg">
                        </div>
                        <div class="price bg-dark ">450万</div>
                        <div class="px-3">
                            <div class="d-flex justify-content-between mt-4 "  >
                                <h5 class="my-color">金域豪庭</h5><p class="text-muted ">宝安-福永</p>
                            </div>
                            <p class="mb-4 my-color">3室2厅96.39平米</p>
                        </div>
                    </a>
                </li>
            </ul>
        </div>
        <!-- f2 新房 -->
        <div class="f2 mt-5">
            <h3>新房，新起航</h3>
            <div class="d-flex justify-content-between my-3">
                <p class="text-muted">真实信息准确同步，楼盘动态一手掌握</p>
                <a href="javascript:;" class="my-color">更多深圳新房</a>
            </div>    
            <ul class="list-unstyled d-flex justify-content-between">
                <li class="items">
                    <a href="javascript:;">
                        <div >
                            <img  src="img/index/xf-1.jpg">
                        </div>
                        <div class="price bg-warning ">预计10月发售</div>
                        <div class="px-3">
                            <h5 class="my-color mt-4">宝能城市公馆三期</h5>
                            <div class="d-flex justify-content-between">
                                <p class="text-muted ">福田-香蜜</p>
                                <p class="mb-4 my-text">售价待定</p>
                            </div>
                        </div>
                    </a>
                </li>
                <li class="items">
                    <a href="javascript:;">
                        <div >
                            <img  src="img/index/xf-2.jpg">
                        </div>
                        <div class="price bg-warning ">预计上半年入市</div>
                        <div class="px-3">
                            <h5 class="my-color mt-4">星都梅沙田邸</h5>
                            <div class="d-flex justify-content-between">
                                <p class="text-muted ">盐田-盐田</p>
                                <p class="mb-4 my-text">售价待定</p>
                            </div>
                        </div>
                    </a>
                </li>
                <li class="items">
                    <a href="javascript:;">
                        <div >
                            <img  src="img/index/xf-3.jpg">
                        </div>
                        <div class="price bg-warning">加推新品</div>
                        <div class="px-3">
                            <h5 class="my-color  mt-4">恒大城二期</h5>
                            <div class="d-flex justify-content-between">
                                <p class="text-muted ">坪山-坪山</p>
                                <p class="mb-4 my-text">38500元/㎡</p>
                            </div>
                        </div>
                    </a>
                </li>
                <li class="items">
                    <a href="javascript:;">
                        <div >
                            <img  src="img/index/xf-4.jpg">
                        </div>
                        <div class="price bg-warning ">9.9折 再减8万</div>
                        <div class="px-3">
                            <h5 class="my-color  mt-4">京基御景半山</h5>
                            <div class="d-flex justify-content-between">
                                <p class="text-muted ">龙岗-龙岗宝荷</p>
                                <p class="mb-4 my-text">38000元/㎡</p>
                            </div>
                        </div>
                    </a>
                </li>
            </ul>
        </div>
        <!-- f3 租房 -->
        <div class="f3 mt-5">
            <h3>租房，舒心省事</h3>
            <div class="d-flex justify-content-between my-3">
                <p class="text-muted">省事省心有放心，好租好搜好房一切尽在猪小窝</p>
                <a href="javascript:;" class="my-color">更多深圳租房</a>
            </div>    
            <ul class="list-unstyled d-flex justify-content-between">
                <li class="items">
                    <a href="javascript:;">
                        <div >
                            <img  src="img/index/zf-1.jpg">
                        </div>
                        <div class="price bg-dark ">2299元/月</div>
                        <div class="px-3">
                            <div class="d-flex justify-content-between mt-4 "  >
                                <h5 class="my-color">龙光玖云著</h5><p class="text-muted ">坪山-坪山</p>
                            </div>
                            <p class="mb-4 my-color">2室1厅51平米</p>
                        </div>
                    </a>
                </li>
                <li class="items">
                    <a href="javascript:;">
                        <div >
                            <img  src="img/index/zf-2.jpg">
                        </div>
                        <div class="price bg-dark ">4100元/月</div>
                        <div class="px-3">
                            <div class="d-flex justify-content-between mt-4 "  >
                                <h5 class="my-color">翡翠园山湖居一期</h5><p class="text-muted ">罗湖-布心</p>
                            </div>
                            <p class="mb-4 my-color">2室1 50平米</p>
                        </div>
                    </a>
                </li>
                <li class="items">
                    <a href="javascript:;">
                        <div >
                            <img  src="img/index/zf-3.jpg">
                        </div>
                        <div class="price bg-dark ">9000元/月</div>
                        <div class="px-3">
                            <div class="d-flex justify-content-between mt-4 "  >
                                <h5 class="my-color">万科云城</h5><p class="text-muted ">南山-西丽</p>
                            </div>
                            <p class="mb-4 my-color">3室2厅98平米</p>
                        </div>
                    </a>
                </li>
                <li class="items">
                    <a href="javascript:;">
                        <div >
                            <img  src="img/index/zf-4.jpg">
                        </div>
                        <div class="price bg-dark ">8200元/月</div>
                        <div class="px-3">
                            <div class="d-flex justify-content-between mt-4 "  >
                                <h5 class="my-color">绿景虹湾</h5><p class="text-muted ">福田-福林</p>
                            </div>
                            <p class="mb-4 my-color">3室2厅89平米</p>
                        </div>
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <!-- 页脚 -->
    <div class="container-fluid bg-dark footer">
        <div class="container">
            <div class="row no-gutters  ">
                <div class="col-8 mt-5">
                    <ul class="list-unstyled d-flex  ">
                        <li  class="mr-3"><a href="">深圳房产网</a></li>
                        <li  class="mr-3"><a href="">二手房</a></li>
                        <li  class="mr-3"><a href="">新房</a></li>
                        <li  class="mr-3"><a href="">租房</a></li>
                        <li  class="mr-3"><a href="">房产顾问</a></li>
                        <li ><a href="">关于我们</a></li>
                    </ul>
                    <ul class="nav nav-tabs border-0 ">
                        <li class="nav-item ">
                            <a class="nav-link active border-0" data-toggle="tab" href="#d1">热门城市二手房</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link border-0 " data-toggle="tab" href="#d2">热门城市新房</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link border-0 " data-toggle="tab" href="#d3">热门城市租房</a>
                        </li>
                    </ul>
                    <div class="tab-content  mb-5">
                        <div id="d1" class="tab-pane alert active px-0">
                            <a class="mr-3" href="javascript:;">深圳二手房</a>
                            <a class="mr-3" href="javascript:;">北京二手房</a>
                            <a class="mr-3" href="javascript:;">上海二手房</a>
                            <a class="mr-3" href="javascript:;">杭州二手房</a>
                            <a class="mr-3" href="javascript:;">珠海二手房</a>
                            <a class="mr-3" href="javascript:;">广州二手房</a>
                            <a  class="mr-3" href="javascript:;">惠州二手房</a>
                        </div>
                        <div id="d2" class="tab-pane alert  px-0">
                            <a class="mr-3" href="javascript:;">深圳新房</a>
                            <a class="mr-3" href="javascript:;">北京新房</a>
                            <a class="mr-3" href="javascript:;">上海新房</a>
                            <a class="mr-3" href="javascript:;">广州新房</a>
                            <a class="mr-3" href="javascript:;">杭州新房</a>
                            <a class="mr-3" href="javascript:;">珠海新房</a>
                            <a class="mr-3" href="javascript:;">惠州新房</a>
                        </div>
                        <div id="d3" class="tab-pane alert px-0">
                            <a class="mr-3" href="javascript:;">深圳租房</a>
                            <a class="mr-3" href="javascript:;">北京租房</a>
                            <a class="mr-3" href="javascript:;">上海租房</a>
                            <a class="mr-3" href="javascript:;">广州租房</a>
                            <a class="mr-3" href="javascript:;">杭州租房</a>
                            <a class="mr-3" href="javascript:;">珠海租房</a>
                            <a class="mr-3" href="javascript:;">惠州租房</a>
                        </div>
                    </div>
                </div>
                <div class="col-4 mt-5 text-center d-flex justify-content-center">
                    <div class="text-danger tel">
                        <h5 class="bg-dark">服务热线</h5>
                         <h3>1011 9988</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
</template>



<script>
export default {
  
}
</script>

<style scoped>
    div.carousel{
        position: relative;
    }
    .container{
        width:1200px;
        min-width: 1200px;
        /* 导航栏 */
    }
    ul.menu{
        height: 40px;
        font-size: 16px;
        color: white;
        position: absolute;
        left:600px;
        bottom: 650px;   
    }
    ul.menu>li:nth-child(even){
        margin:0 50px;
    }
    ul.menu>li{
        position:relative;
    }
    ul.menu>li>ul{ 
        font-size: 14px;
        background-color:rgba(0, 0, 0, .3);
        position:absolute;
        top:30px;
        left: -40px;
        width:0px;
        height:0px;
        overflow:hidden;
        top:54px;
        opacity:0;
        transition:top .5s linear, opacity .5s linear;
    }
    ul.menu>li>ul>li{
        display:block;
        text-align:center;
        padding:10px;
        height:40px; 
        line-height:40px;
        width:120px; 
      }
      ul.menu>li:hover{
      color: #fed243;
      }
      ul.menu>li>ul>li>a:hover,ul.menu>li>a:hover{
        color: #fed243;
        text-decoration: none;
    }
      ul.menu>li:hover>ul{
        top:40px;
        opacity:1;
        width:130px;
        height:130px;
      }
      /* 搜索区 */
      div.seach{
          width:650px;height: 160px;
          font-size: 14px;
          background-color:rgba(0, 0, 0, .3);
          position: absolute;
          left: 50%;
          bottom:200px ;
          margin-left: -325px;
      }
      div.seach>ul{
          color:#fff;
      }
      div.seach>ul>li:hover{
          color:#fed243;
      }
      div.seach>div>input{
          height: 45px;
          font-size: 14px   ;
          border-radius:5px 0 0 5px  ;
          border: 0;outline: 0;
      }
      div.seach>div>button{
        height: 45px;width: 100px;
        border-radius:0 5px 5px 0 ;
        border: 0;
    }
    div.seach>div>input:focus,div.seach>div>button:focus{
        box-shadow:none !important;
    }
    /* 房区入口 */
    div.entrances{
        height:150px;
        font-size:20px;
        text-align: center;   
    }
    div.entrances p{
        color: #333;
        margin-top:10px;
    }
    div.entrances:hover{
        background-color: #fff;
        transform: translateY(-5px);
        transition:all .3s ease-in-out
    }
    div.entrances>a{
      display: inline-block;
      padding-top: 25px;
    }
    /*f1二手房 */
    ul>li.items{
    background-color: #fff;
    border-radius: 8px;
    transition: all .3s ease-in-out;
    position: relative;
    }
    ul>li.items:hover{
        transform: translateY(-5px);
    }
    ul>li.items img{
        border-radius: 8px 8px 0 0;
    }
    ul>li.items h5{
        font-size: 20px;
        font-weight: 700;
    }
    ul>li.items .price{
        text-align: center;
        line-height: 30px;
        font-size: 16px;
        color:#fed243;
        position: absolute;
        right: 0;
        top:180px;
    }
    .f1>ul>li.items .price{
        width: 60px;
        
    }
    /*f2 新房 */
    .f2>ul>li.items .price{
        width: 110px;height:25px;
        text-align: center;
        font-size: 14px;
        color: #333;
        line-height: 25px;
        border-radius:15px;
        position: absolute;
        left:10px;
        top:10px;
    }
    .my-text{
        color: #333;
        font-size:22px ;
    }
    /*f3 租房 */
    .f3>ul>li.items .price{
        width: 90px;
    }
    /* 页脚 */
    .nav-tabs .nav-link.active,
    .nav-tabs .nav-item.show .nav-link {
        width: 140px;
        text-align: center;
        color:#fff;
        background-color:#444;
        border-color:transparent;
        border-radius: 0;
    }
    div.tel{
        margin-top:10px ;
        width: 240px;height:100px;
        border:3px solid #555
    }
    div.tel>h5{
          width:100px;
          margin-left:65px;
          margin-top:-15px ;
    }
    div.tel>h3{
        margin-top:28px;
    }
</style>