<template>
    <div class="parent">
        <div class="main">
            <div>
                <router-link to="/">
                    <img src="../../public/img/logo.png" class="w-25">
                </router-link>
                <p class="mb-0 text-light">猪小窝房屋管理平台</p>
            </div>
            <input type="text" placeholder="请输入手机号" v-model="phone" @blur="vali" class="px-2 py-2 w-100 phone"><br>
            <span  class="vali" :class="spanClass">{{msg}}</span>
            <input type="password" placeholder="请输入密码" v-model="pwd" @blur="vali_pwd" class="mb-3 px-2 py-2 w-100">
            <span  class="vali" :class="spanClass">{{msg1}}</span>
            <div class="msg"><span>用户名或密码错误，请核实后再试试吧！</span></div>
            <router-link to="personal">
                <button class="w-100 mt-3" @click="login">登 录</button>
            </router-link>
            <div class="justify-content-md-between">
                <router-link to="/">
                    忘记密码？
                </router-link>
                <span class="text-light">还没有账号？现在就去<router-link to="/register">注册</router-link></span>
            </div>
        </div>
    </div>
</template>
<style>
    .parent{background: url(../../public/img/house_login.jpg)  center center ;height:800px;}
    .main{width: 350px;position: relative;left: 490px;top:200px;}
    /*设置输入框整体样式 */
    .main input{border-radius: 5px; outline: none;border:0;height:50px;}
    .main input:onfocus{outline:0}
    /*设置提示框的样式 */
    .msg{background-color: rgba(200, 200, 200, .5);height: 60px;line-height: 60px;border-radius: 5px;color:red}
    /*设置第一个输入框下边框*/
    .main>.phone{border-bottom: 1px solid gray;}
    .main button{background-color: #15D0CD; outline: none; border:0;border-radius: 5px;height:35px;font-size: 20px;}
    
    .vali{/*始终在span上保持不变*/padding:5px;}
    .success{border:1px solid green;background-color:lightGreen;color:green;} 
    .fail{border:1px solid red;background-color:pink;color:red;}
</style>

<script>
export default {
    data(){
        return {
            phone:"",
            pwd:"",
            msg:"",
            msg1:"",
            spanClass:{
                success:false,
                fail:false
            }
        }
    },
    methods:{
        vali(){
            //定义验证手机号的正则表达式
            var reg=/^1[3-9]\d{9}$/;
            //如果phone接到的手机号格式正确
            //因为test()返回值本来就是bool，所以不需要再写==true
            if(reg.test(this.phone)){
                //就修改spanClass中的success为true，fail为false
                this.spanClass={success:true,fail:false};
                //同时修改msg为"手机号格式正确"
                this.msg="手机号格式正确";}
                else{
                    //否则phone接到的手机号格式不正确
                    //就修改spanClass中的success为false，fail为true
                    this.spanClass={success:false,fail:true};
                    //同时修改msg为"手机号格式不正确"
                    this.msg="手机号格式不正确";}
                },
        vali_pwd(){
            //定义验证手机号的正则表达式
            var reg=/^[a-zA-Z0-9]{6,12}]$/;
            //如果phone接到的手机号格式正确
            //因为test()返回值本来就是bool，所以不需要再写==true
            if(reg.test(this.pwd)){
                //就修改spanClass中的success为true，fail为false
                this.spanClass={success:true,fail:false};
                //同时修改msg为"密码格式正确"
                this.msg1="密码格式正确";}
                else{
                    //否则phone接到的密码格式不正确
                    //就修改spanClass中的success为false，fail为true
                    this.spanClass={success:false,fail:true};
                    //同时修改msg为"密码格式不正确"
                    this.msg1="密码格式不正确";}
                },
            login(){
            
        }
    }
}
</script>