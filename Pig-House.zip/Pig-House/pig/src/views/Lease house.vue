<template>
    <div>
        <!-- 引入头组件信息 -->
        <my-header></my-header>
        <div class="container">
            <div class='contain'>
            <div class="left">
                <ul>
                <li class="clearfix">
                    <a href="javascript:;">
                    <img src="img/1.png" alt="">
                    </a>
                    <div class="msg">
                    <h5 class="title">
                        <a href="javascript:;">新领地花木星辰苑 29楼</a>
                    </h5>
                    <p class="house-details">
                        <span>浦东-花木 | 合租 | 2室0厅1卫 | 40M² | 朝东北-次卧</span>
                    </p>
                    <div class="house-address">
                        <img class="icon-pos" src="img/pos.png" alt="">
                        <span>距离2号线世纪公园地铁站807米</span>
                    </div>
                    <div class="house-light">
                        <span>月付</span>
                        <span>近地铁</span>
                        <span>独卫</span>
                        <span>新上架</span>
                    </div>
                    </div>
                    <div class="price">
                    <span>1800元</span>
                    </div>
                </li>
                <li class="clearfix">
                    <a href="javascript:;">
                    <img src="img/2.png" alt="">
                    </a>
                    <div class="msg">
                    <h5 class="title">
                        <a href="javascript:;">陆家角馨苑西区 3楼</a>
                    </h5>
                    <p class="house-details">
                        <span>青浦-徐泾 | 合租 | 1室0厅0卫 | 20M² | 朝东南-次卧</span>
                    </p>
                    <div class="house-address">
                        <img class="icon-pos" src="img/pos.png" alt="">
                        <span>距离尚茂路乐爱路公交站166米</span>
                    </div>
                    <div class="house-light">
                        <span>月付</span>
                        <span>近地铁</span>
                        <span>独卫</span>
                        <span>新上架</span>
                    </div>
                    </div>
                    <div class="price">
                    <span>1880元</span>
                    </div>
                </li>
                <li class="clearfix">
                    <a href="javascript:;">
                    <img src="img/3.png" alt="">
                    </a>
                    <div class="msg">
                    <h5 class="title">
                        <a href="javascript:;">和源名城 31楼</a>
                    </h5>
                    <p class="house-details">
                        <span>静安-彭浦 | 合租 | 1室0厅0卫 | 10M² | 朝东北-次卧</span>
                    </p>
                    <div class="house-address">
                        <img class="icon-pos" src="img/pos.png" alt="">
                        <span>距离3号线殷高西路地铁站1769米</span>
                    </div>
                    <div class="house-light">
                        <span>月付</span>
                        <span>电梯房</span>
                        <span>独卫</span>
                        <span>新上架</span>
                    </div>
                    </div>
                    <div class="price">
                    <span>1100元</span>
                    </div>
                </li>
                <li class="clearfix">
                    <a href="javascript:;">
                    <img src="img/4.png" alt="">
                    </a>
                    <div class="msg">
                    <h5 class="title">
                        <a href="javascript:;">江南名庐 1楼</a>
                    </h5>
                    <p class="house-details">
                        <span>普陀-武宁 | 整租 | 2室1厅1卫 | 110M² | 朝西北</span>
                    </p>
                    <div class="house-address">
                        <img class="icon-pos" src="img/pos.png" alt="">
                        <span>距离3号线曹杨路地铁站208米</span>
                    </div>
                    <div class="house-light">
                        <span>月付</span>
                        <span>近地铁</span>
                        <span>电梯房</span>
                    
                    </div>
                    </div>
                    <div class="price">
                    <span>8800元</span>
                    </div>
                </li>
                <li class="clearfix">
                    <a href="javascript:;">
                    <img src="img/5.png" alt="">
                    </a>
                    <div class="msg">
                    <h5 class="title">
                        <a href="javascript:;">百鸟苑 7楼</a>
                    </h5>
                    <p class="house-details">
                        <span>松江-泗泾 | 合租 | 1室0厅0卫 | 30M² | 朝东北-次卧</span>
                    </p>
                    <div class="house-address">
                        <img class="icon-pos" src="img/pos.png" alt="">
                        <span>距离9号线洞泾地铁站632米</span>
                    </div>
                    <div class="house-light">
                        <span>近地铁</span>
                        <span>新上架</span>
                        <span>非一楼</span>
                    </div>
                    </div>
                    <div class="price">
                    <span>1399元</span>
                    </div>
                </li>
                <li class="clearfix">
                    <a href="javascript:;">
                    <img src="img/6.png" alt="">
                    </a>
                    <div class="msg">
                    <h5 class="title">
                        <a href="javascript:;">合生江湾国际公寓 9楼</a>
                    </h5>
                    <p class="house-details">
                        <span>杨浦-新江湾城 | 合租 | 1室0厅0卫 | 10M² | 朝西北-次卧</span>
                    </p>
                    <div class="house-address">
                        <img class="icon-pos" src="img/pos.png" alt="">
                        <span>距离10号线新江湾城地铁站1612米</span>
                    </div>
                    <div class="house-light">
                        <span>电梯房</span>
                        <span>独卫</span>
                        <span>新上架</span>
                    </div>
                    </div>
                    <div class="price">
                    <span>2260元</span>
                    </div>
                </li>
                <li class="clearfix">
                    <a href="javascript:;">
                    <img src="img/7.png" alt="">
                    </a>
                    <div class="msg">
                    <h5 class="title">
                        <a href="javascript:;">红枫苑 6楼</a>
                    </h5>
                    <p class="house-details">
                        <span>浦东-三林 | 合租 | 1室0厅0卫 | 13M² | 朝西南</span>
                    </p>
                    <div class="house-address">
                        <img class="icon-pos" src="img/pos.png" alt="">
                        <span>距离11号线三林东地铁站848米</span>
                    </div>
                    <div class="house-light">
                        <span>近地铁</span>
                        <span>独卫</span>
                        <span>非一楼</span>
                    </div>
                    </div>
                    <div class="price">
                    <span>2200元</span>
                    </div>
                </li>
                <li class="clearfix">
                    <a href="javascript:;">
                    <img src="img/8.png" alt="">
                    </a>
                    <div class="msg">
                    <h5 class="title">
                        <a href="javascript:;">城市方园 31楼</a>
                    </h5>
                    <p class="house-details">
                        <span>杨浦-中原社区 | 合租 | 1室0厅0卫 | 20M² | 朝东北-次卧</span>
                    </p>
                    <div class="house-address">
                        <img class="icon-pos" src="img/pos.png" alt="">
                        <span>距离8号线市光路地铁站1347米</span>
                    </div>
                    <div class="house-light">
                        <span>月付</span>
                        <span>独卫</span>
                        <span>带阳台</span>
                        <span>新上架</span>
                    </div>
                    </div>
                    <div class="price">
                    <span>2680元</span>
                    </div>
                </li>
                <li class="clearfix">
                    <a href="javascript:;">
                    <img src="img/9.png" alt="">
                    </a>
                    <div class="msg">
                    <h5 class="title">
                        <a href="javascript:;">虹翔公寓 5楼</a>
                    </h5>
                    <p class="house-details">
                        <span>嘉定-南翔 | 合租 | 1室0厅0卫 | 15M² | 朝西北-次卧</span>
                    </p>
                    <div class="house-address">
                        <img class="icon-pos" src="img/pos.png" alt="">
                        <span>距离11号线南翔地铁站1644米</span>
                    </div>
                    <div class="house-light">
                        <span>月付</span>
                        <span>非一楼</span>
                        <span>独卫</span>
                        <span>新上架</span>
                    </div>
                    </div>
                    <div class="price">
                    <span>1300元</span>
                    </div>
                </li>
                <li class="clearfix">
                    <a href="javascript:;">
                    <img src="img/10.png" alt="">
                    </a>
                    <div class="msg">
                    <h5 class="title">
                        <a href="javascript:;">宝菊新家园 6楼</a>
                    </h5>
                    <p class="house-details">
                        <span>嘉定-菊园新区 | 合租 | 1室0厅0卫 | 10M² | 朝西南-次卧</span>
                    </p>
                    <div class="house-address">
                        <img class="icon-pos" src="img/pos.png" alt="">
                        <span>距离地铁站958米</span>
                    </div>
                    <div class="house-light">
                        <span>月付</span>
                        <span>近地铁</span>
                        <span>电梯房</span>
                        <span>新上架</span>
                    </div>
                    </div>
                    <div class="price">
                    <span>1200元</span>
                    </div>
                </li>
                <li class="clearfix">
                    <a href="javascript:;">
                    <img src="img/20.png" alt="">
                    </a>
                    <div class="msg">
                    <h5 class="title">
                        <a href="javascript:;">爱博五村 11楼</a>
                    </h5>
                    <p class="house-details">
                        <span>闵行-华漕 | 合租 | 1室0厅0卫 | 28M² 朝东北-次卧 </span>
                    </p>
                    <div class="house-address">
                        <img class="icon-pos" src="img/pos.png" alt="">
                        <span>距离北翟路申长路公交站304米</span>
                    </div>
                    <div class="house-light">
                        <span>月付</span>
                        <span>电梯房</span>
                        <span>新上架</span>
                    </div>
                    </div>
                    <div class="price">
                    <span>2400元</span>
                    </div>
                </li>
                <li class="clearfix">
                    <a href="javascript:;">
                    <img src="img/22.png" alt="">
                    </a>
                    <div class="msg">
                    <h5 class="title">
                        <a href="javascript:;">中环国际公寓1期 5楼</a>
                    </h5>
                    <p class="house-details">
                        <span>宝山-共康 | 合租 | 1室0厅0卫 | 18M² | 朝东北-主卧</span>
                    </p>
                    <div class="house-address">
                        <img class="icon-pos" src="img/pos.png" alt="">
                        <span>距离1号线呼兰路地铁站1222米</span>
                    </div>
                    <div class="house-light">
                        <span>月付</span>
                        <span>保洁服务</span>
                        <span>电梯房</span>
                        <span>新上架</span>
                    </div>
                    </div>
                    <div class="price">
                    <span>1600元</span>
                    </div>
                </li>
                </ul>
            </div>

            <div class="right">
                <ul>
                <li>
                    <div>
                    <a href="javascript:;">
                        <img src="img/11.png" alt="">
                    </a>
                    </div>
                    <div class="msg">
                    <h5 class="title">玉宏星天地 9楼
                        <div class="price">
                        <span>2400元</span>
                        </div>
                    </h5>
                    <p class="house-details">
                        <span>嘉定-南翔 | 合租 | 1室0厅1卫 | 20M²</span>
                    </p>
                    <div class="house-light">
                        <span>月付</span>
                        <span>近地铁</span>
                        <span>独卫</span>
                        <span>新上架</span>
                    </div>
                    </div>
                </li>
                <li>
                    <div>
                    <a href="javascript:;">
                        <img src="img/12.png" alt="">
                    </a>
                    </div>
                    <div class="msg">
                    <h5 class="title">三湘四季花城 5楼
                        <div class="price">
                        <span>1800元</span>
                        </div>
                    </h5>
                    <p class="house-details">
                        <span>松江-松江大学城 | 合租 | 1室0厅0卫 | 20M²</span>
                    </p>
                    <div class="house-light">
                        <span>月付</span>
                        <span>近地铁</span>
                        <span>电梯房</span>
                        <span>非一楼</span>
                    </div>
                    </div>
                </li>
                <li>
                    <div>
                    <a href="javascript:;">
                        <img src="img/13.png" alt="">
                    </a>
                    </div>
                    <div class="msg">
                    <h5 class="title">住友公寓 17楼
                        <div class="price">
                        <span>2800元</span>
                        </div>
                    </h5>
                    <p class="house-details">
                        <span>徐汇-万体馆 | 合租 | 1室0厅0卫 | 20M²</span>
                    </p>
                    <div class="house-light">
                        <span>近地铁</span>
                        <span>独卫</span>
                        <span>新上架</span>
                    </div>
                    </div>
                </li>
                <li>
                    <div>
                    <a href="javascript:;">
                        <img src="img/14.png" alt="">
                    </a>
                    </div>
                    <div class="msg">
                    <h5 class="title">枫叶公寓 4楼
                        <div class="price">
                        <span>2660元</span>
                        </div>
                    </h5>
                    <p class="house-details">
                        <span>虹口-江湾镇 | 合租 | 1室0厅0卫 | 14M²</span>
                    </p>
                    <div class="house-light">
                        <span>近地铁</span>
                        <span>非一楼</span>
                        <span>新上架</span>
                    </div>
                    </div>
                </li>
                <li>
                    <div>
                    <a href="javascript:;">
                        <img src="img/15.png" alt="">
                    </a>
                    </div>
                    <div class="msg">
                    <h5 class="title">富锦苑 6楼
                        <div class="price">
                        <span>1490元</span>
                        </div>
                    </h5>
                    <p class="house-details">
                        <span>宝山-月浦 | 合租 | 1室0厅0卫 | 20M²</span>
                    </p>
                    <div class="house-light">
                        <span>月付</span>
                        <span>近地铁</span>
                        <span>独卫</span>
                        <span>新上架</span>
                    </div>
                    </div>
                </li>
                </ul>

            </div>     
            </div>
            <!-- 分页按钮 -->
            <div class="page">
            <ul>
                <li> 上一页</li>
                <li tabindex="1">1</li>
                <li tabindex="2">2</li>
                <li tabindex="3">3</li>
                <li tabindex="4">4</li>
                <li tabindex="5">5</li>
                <li tabindex="6">6</li>
                <li tabindex="7">7</li>
                <li tabindex="8">8</li>
                <li>下一页</li>
            </ul>
            </div>

            <ul class="side">
            <li>
                <img src="img/ed.png" alt="">
            </li>
            <li>
                <img src="img/tel.png" alt="">
            </li>
            <li>
                <a href="#">
                <img src="img/totop.png" alt="">
                </a>
            </li>
            </ul>
            </div>
    </div>
</template>
<style scoped>
    *{
  margin:0;
  padding:0;
}
body{
  background-color: #e9e9e9;
}
.clearfix:after{
  content:'';
  display: block;
  height:0;
  clear: both;
}
.contain{
  width:100%;
  display: flex;
  justify-content: center;
}
.left{
  width:900px;
  background-color:#fff;
  margin-right:20px;
}
ul{
  list-style: none;
}
.left ul>li{
  width:900px;
  padding:18px;
  border-bottom: 1px solid #ddd;
}
.left li img{
  width:212px;
  height:158px;
  border-radius:4px;
  float: left;
}
.left li div.msg{
  float:left;
  margin-left:28px;
  width:450px;
}
.msg .title{
  width: 100%;
  font-weight: bolder;
}
.msg .title a,.msg .title .a:hover{
  text-decoration: none;
  color: #212529;
}

.price>span{
  float:right;
  color:#f00;
  font-weight: 500;
  font-size: 22px;
}
p{
  padding: 0;
  margin:0;
}
.msg .house-details{
  font-size: 15px;
  margin-bottom: 10px;
}
.msg .house-address{
  font-size:14px;
  color:#888;
  margin-bottom: 10px;
}
.msg .icon-pos{
  width:16px;
  height:16px;
}
.msg .house-light span{
  background-color: #e9e9e9;
 
  font-size: 14px;
  color:#666;
  margin-right:2px;
  padding-left:  6px;
  padding-right: 6px;
  border-radius:4px;
}

.right{
  width:270px;
}
.right img{
  width:270px;
  height:182px;
  border-radius:4px;
}
.right ul{
  display: flex;
  flex-direction: column;
}
.right ul>li{
  background-color: #fff;
  margin-bottom: 18px;
}
.right div.msg{
  width:270px;
  height:95px;
  padding:10px;
}
.right .msg .title{
  margin-bottom:0;
  font-size:17px;
  font-weight: bolder;
  margin-bottom:4px;
}
.right .msg .price{
  float: right;
  line-height: 0;
  margin-top:8px;
  font-size:24px;
}
.right .msg .house-details{
  margin-bottom:2px;
  font-size:14px;
}
.right .house-light>span:first-child{
  color:#f00;
  background-color: #fdd;
}
.right .house-light>span+span{
  color:#0aa1ed;
  background-color: #ddf;
}

ul.side{
  position:fixed;
  right:10px;
  bottom:100px;
}
ul.side>li{
  margin-bottom: 15px;
  background-color: #fff;
  padding:8px;
  border-radius:6px;
}
.page{
  margin-top:40px;
  
}
.page>ul{
  display:flex;
  justify-content: center;

}
.page ul li{
  display:inline-block;
  padding:5px 12px;
  background-color:#fff;
  border:0;
  border-radius:2px;
}
.page ul li+li{
  margin-left:7px;
}
.page ul li:hover{
  background-color: transparent;
  border:1px solid #afa;
}
.page ul li.active,.page ul li:focus{
  background-color: rgb(170, 183, 255);
  color:#fff;
  border:0;
  outline: transparent;
}
</style>