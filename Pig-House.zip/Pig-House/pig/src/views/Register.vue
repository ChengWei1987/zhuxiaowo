<template>
    <div class="parent">
        <div class="main">
            <div>
                <router-link to="/">
                    <img src="../../public/img/logo.png" class="w-25">
                </router-link>
                <p class="mb-0 text-light">猪小窝房屋管理平台</p>
            </div>
            <input type="text" placeholder="请输入手机号" class="px-2 py-2 w-100" v-model="phone" @blur="vali"><br>
            <span  class="vali" :class="spanClass">{{msg}}</span>
            <input type="password" placeholder="请输入密码" class="px-2 py-2 w-100 mb-0" v-model="pwd" @blur="vali_pwd">
            <span  class="vali" :class="spanClass">{{msg1}}</span>
            <input type="password" placeholder="请再次输入密码" class=" px-2 py-2 w-100" v-model="cpwd" @blur="vali_cpwd">
            <span  class="vali" :class="spanClass">{{msg2}}</span>
            <Jc status="status" class="mt-2"></Jc>
            <router-link to="personal">
                <button class="w-100 mt-3" @click="register">注册</button>
            </router-link>
            <div class="justify-content-md-between">
                <router-link to="/">
                    忘记密码？
                </router-link>
                <span class="text-light">已有账号，现在就去<router-link to="/login">登录</router-link></span>
            </div>
        </div>
    </div>
</template>

<style scoped>
    .parent{background: url(../../public/img/house_register.jpg)  center center ;height:800px;}
    .main{width: 350px;height:280px;position: relative;left: 490px;top:200px;}
    /*设置输入框整体样式 */
    .main input{border-radius: 5px; outline: none;border:0;height:50px;}
    .main input:onfocus{outline:0}
    /*设置提示框的样式 */
    .msg{background-color: rgba(200, 200, 200, .5);height: 60px;line-height: 60px;border-radius: 5px;color:red}
    /*设置第一个输入框下边框*/
    .main>input:not(:last-child){border-bottom:1px solid gray}
    .main button{background-color: #15D0CD; outline: none; border:0;border-radius: 5px;height:35px;font-size: 20px;}
</style>

<script>
export default {
    data(){
        return {
            status: false,
            phone:"",
            pwd:"",
            cpwd:"",
            msg:"",
            msg1:"",
            msg2:"",
            spanClass:{
                success:false,
                fail:false
            }
        }
    },
    methods:{
        vali(){
            //定义验证手机号的正则表达式
            var reg=/^1[3-9]\d{9}$/;
            //如果phone接到的手机号格式正确
            //因为test()返回值本来就是bool，所以不需要再写==true
            if(reg.test(this.phone)){
                //就修改spanClass中的success为true，fail为false
                this.spanClass={success:true,fail:false};
                //同时修改msg为"手机号格式正确"
                this.msg="手机号格式正确";}
                else{
                    //否则phone接到的手机号格式不正确
                    //就修改spanClass中的success为false，fail为true
                    this.spanClass={success:false,fail:true};
                    //同时修改msg为"手机号格式不正确"
                    this.msg="手机号格式不正确";}
                },
        vali_pwd(){
            //定义验证手机号的正则表达式
            var reg=/^[a-zA-Z0-9]{6,12}]$/;
            //如果phone接到的手机号格式正确
            //因为test()返回值本来就是bool，所以不需要再写==true
            if(reg.test(this.pwd)){
                //就修改spanClass中的success为true，fail为false
                this.spanClass={success:true,fail:false};
                //同时修改msg为"密码格式正确"
                this.msg1="密码格式正确";}
                else{
                    //否则phone接到的密码格式不正确
                    //就修改spanClass中的success为false，fail为true
                    this.spanClass={success:false,fail:true};
                    //同时修改msg为"密码格式不正确"
                    this.msg1="密码格式不正确";}
                },
        vali_cpwd(){
            if(this.cpwd!=this.pwd){
                this.spanClass={success:false,fail:true};
                this.msg2="两次输入的密码不一致"
            }else{
                this.spanClass={success:true,fail:false};
                this.msg2="密码已确认"
            }
        },
        register(){}    
    }
}
</script>
        
