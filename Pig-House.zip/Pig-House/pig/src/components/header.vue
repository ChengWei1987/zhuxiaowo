<template>
    <div class="header">
        <div class="container">
    	<!-- 上部分 -->
        <!-- 左侧logo部分 -->
    	<div class="row">
    		<div class="col-md-12 col-lg-3 col-sm-12 pt-1">
    			<router-link class="navbar-brand pt-0" to="/">
    				<img src="img/logo.png" alt="" >
                    <span id="title">猪小窝房屋管理平台</span>
    			</router-link>
    		</div>
            <!-- 中间导航栏部分 -->
    		<div class="col-md-12 col-lg-6 col-sm-12 ">
    			<div class="input-group">
    				<ul class="nav">
                        <li class="nav-item"><router-link to="/" class="nav-link">首页</router-link></li>
                        <li class="nav-item"><router-link to="new house" class="nav-link">新房</router-link></li>
                        <li class="nav-item"><router-link to="old house" class="nav-link">二手房</router-link></li>
                        <li class="nav-item"><router-link to="lease house" class="nav-link">租房</router-link></li>
                        <li class="nav-item"><router-link to="join me" class="nav-link">加入小窝</router-link></li>
                        <li class="nav-item"><router-link to="about me" class="nav-link">关于小窝</router-link></li>
                    </ul>
    			</div>
    		</div>
            <!-- 右侧注册登录信息 -->
    		<div class="col-md-12 col-lg-3 col-sm-12 pt-1">
    			<ul class="breadcrumb bg-transparent pl-md-0 pl-lg-5 mb-0">
    				<li class="breadcrumb-item">
    					<router-link to="personal">
    						<img src="img/personal.png" >
    					</router-link>
    				</li>
    				<li class="breadcrumb-item">
    					<router-link to="register">注册</router-link>
    				</li>
    				<li class="breadcrumb-item ">
    					<router-link to="login">登录</router-link>
    				</li>
    			</ul>
    		</div>
    	</div>
   
    </div>
    </div>
</template>
<style scoped>
    /*设置背景颜色 高度等*/
    .header{width: 100%;height: 56px;background-color:rgba(56,56,56,.5);color:#ede;display: flex;}
    /*logo文字的样式 */
    #title{font-family:Georgia, 'Times New Roman', Times, serif; font-size: 16px; vertical-align: bottom;}
    /*设置logo图片的大小 */
    .navbar-brand img{width: 21%;}
    /*设置导航栏的高度 */
    .input-group{height: 56px; line-height: 40px;}
    /*登录注册字体样式 */
    .nav-link{color:#fff;font-size:18px;font-weight: 500;}
    .breadcrumb-item >a{color:#fff;}
    /*滑动效果 */
    .nav>li:hover{background-color: rgb(58, 63, 63);}
</style>