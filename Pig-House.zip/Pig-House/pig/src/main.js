import Vue from 'vue'
import App from './App.vue'
import router from './router'
import axios from 'axios'
import MyHeader from './components/header.vue'
import Jc from './components/JcRange.vue'

axios.defaults.baseURL="http://localhost:8080"
Vue.config.productionTip = false
Vue.prototype.axios=axios
Vue.component('my-header',MyHeader)
Vue.component('Jc',Jc)

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
