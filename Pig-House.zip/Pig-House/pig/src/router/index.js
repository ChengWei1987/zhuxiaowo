import Vue from 'vue'
import VueRouter from 'vue-router'
import Index from '../views/Index.vue'
import Header from '../components/header'



Vue.use(VueRouter)

  const routes = [
  {
    path: '/',
    name: 'Index',
    component: Index
  },
  {
    path:'/header',
    component:Header
  },
  {
    path: '/about me',
    name: 'About me',
    component: () => import(/* webpackChunkName: "about" */ '../views/About me.vue')
  },
  {
    path: '/join me',
    name: 'Join me',
    component: () => import(/* webpackChunkName: "about" */ '../views/Join me.vue')
  },
  {
    path: '/new house',
    name: 'New house',
    component: () => import(/* webpackChunkName: "about" */ '../views/New house.vue')
  },
  {
    path: '/old house',
    name: 'Old house',
    component: () => import(/* webpackChunkName: "about" */ '../views/Old house.vue')
  },
  {
    path: '/lease house',
    name: 'Lease house',
    component: () => import(/* webpackChunkName: "about" */ '../views/Lease house.vue')
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import(/* webpackChunkName: "about" */ '../views/Login.vue')
  },
  {
    path: '/register',
    name: 'Register',
    component: () => import(/* webpackChunkName: "about" */ '../views/Register.vue')
  },
  {
    path: '/personal',
    name: 'Personal',
    component: () => import(/* webpackChunkName: "about" */ '../views/Personal.vue')
  },
  {
    path: '/orderlist',
    name: 'orderlist',
    component: () => import(/* webpackChunkName: "about" */ '../views/Orderlist.vue')
  },
]

const router = new VueRouter({
  routes
})

export default router
