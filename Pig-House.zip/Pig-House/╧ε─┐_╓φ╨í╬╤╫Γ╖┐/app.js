const express=require('express');
const bodyParser=require('body-parser');
const userRouter=require('./routes/user.js');//引入自定义的用户路由器模块
const houseRouter=require('./routes/house.js');//引入小窝路由器模块


var server=express();//创建web服务器
server.listen(3000);

//托管静态资源到public目录下
server.use(express.static('public'));

//使用body-parser中间件将post请求数据解析为对象
//注意：一定要写在路由的前边
server.use(bodyParser.urlencoded({
	extended:false//不使用扩展 使用核心querystring
}));


//把用户路由器挂载到/user
server.use('/user',userRouter);//路由级中间件
//浏览器访问形式变成了：/user/register

//把商品路由器挂载到/product
server.use('/house',houseRouter);
//浏览器访问形式为：/product/test



