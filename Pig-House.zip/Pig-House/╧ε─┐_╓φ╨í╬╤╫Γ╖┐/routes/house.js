const express=require('express');

//引入连接池
const pool=require('../pool.js');

var router=express.Router();//创建空路由器

//创建路由

//1.创建路由————查询所有房屋列表  url:/list  method:get
router.get('/list',(req,res)=>{
	var obj=req.query;//获取请求的数据(对象)
	//console.log(obj);
	//判断页码和数量如果为空(页面没有输入)，设置默认值
	var $pno=parseInt(obj.pno);//将页码和数量转为整型
	var $count=parseInt(obj.count);
	if(!$pno){//设置页码为空时的默认值
		$pno=1;
	}
	if(!$count){//设置数量为空时的默认值
		$count=5;
	}
	//计算开始查询的值
	var start=($pno-1)*$count;
	//执行SQL语句,响应查询到的数据，显示要查询的页面
	pool.query('SELECT * FROM house LIMIT ?,?',
		[start,$count],
		(err,result)=>{
			if(err) throw err;
			res.send(result);
	});//查询时，SQL执行结果result是一个数组，里面元素是查询到的数据的对象
});

//2.创建路由————查询房子详情
router.get('/detail',(req,res)=>{
	var obj=req.query;//获取浏览器请求的数据
	//console.log(obj);
	var $hid=obj.hid;
	//验证请求的数据是否为空
	if(!$hid){
		res.send({code:401,msg:'hid required'});
		return;//验证不通过则 不往后执行
	}
	//执行SQL语句，把查询的数据响应给浏览器
	pool.query('SELECT * FROM house	WHERE hid=?',
		[$hid],
		(err,result)=>{
			if(err) throw err;
			//console.log(result);
			//判断查询到的数据是否为空
			if(result.length>0){//查询到有数据才响应结果
				res.send(result);
			}
			else{//如果找不到数据（服务器中没有）
				res.send({code:402,msg:'detail err'});
			}
	});
});

//3.创建路由————删除 按说用户没有删除数据权限，只在前台操作，此接口可不用
router.get('/delete',(req,res)=>{
	//获取请求的数据
	var obj=req.query;
	var $hid=obj.hid;
	//验证是否为空
	if(!$hid){
		res.send({code:401,msg:'hid required'});
		return;
	}
	//执行SQL语句,删除lid对应的数据(记录)
	pool.query('DELETE FROM house WHERE hid=?',
		[$hid],
		(err,result)=>{
			if(err) throw err;
			//判断affectedRows属性值是否大于0
			if(result.affectedRows>0){
				res.send({code:200,msg:'delete suc'});
			}
			else{//当输入不存在的商品编号时
				res.send({code:301,msg:'delete err'});
			}
	});
});

//4.创建路由————添加房源
router.post('/add',(req,res)=>{
	var obj=req.body;//获取post请求的数据
	//console.log(obj);
	//判断是否为空
	//遍历对象的属性
	var $code=400;
	for (var key in obj)
	{
		$code++;
		//console.log(key+'---'+obj[key]);
		//判断属性值是否为空
		if(!obj[key]){
			res.send({code:$code,msg:key+' required'});
			return;
		}
	}
	//执行SQL语句
	pool.query('INSERT INTO user SET ?',
		[obj],
		(err,result)=>{
			if(err) throw err;
			//console.log(result);//打印SQL执行结果
			if(result.affectedRows>0){
				res.send({code:200,msg:'add suc'});
			}
	});
});

//5.完成房屋信息更改路由
router.post('/update',(req,res)=>{
	var obj=req.body;//获取请求的数据
	//console.log(obj);
	//遍历对象的属性，验证属性值是否为空
	var $code=400;
	for(var key in obj){
		$code++;
		if(!obj[key]){
			res.send({code:$code,msg:key+' required'});
			return;
		}
	}
	var $hid=obj.hid;
	var $housetypes=obj.housetypes;
	var $price=obj.price;
	var $manage=obj.manage;
	var $maker=obj.maker;
	var $floors=obj.floors;
	var $housequantity=obj.housequantity;
	var $nearbyshop=obj.nearbyshop;
	//执行SQL语句
	pool.query('UPDATE house SET housetypes=?,price=?,manage=?,maker=?,floors=?,housequantity=?,nearbyshop=? WHERE hid=?',
		[$housetypes,$price,$manage,$maker,$floors,$housequantity,$nearbyshop,$hid],
		(err,result)=>{
			if(err) throw err;
			if(result.affectedRows>0){
				res.send({code:200,msg:'update suc'});
			}
			else{
				res.send({code:301,msg:'update err'});
			}
	});

});


//导出路由器
module.exports=router;

//在app.js服务器文件中挂载到/product下





