//引入上一级目录下的mysql连接池对象
const pool=require('../pool.js');

const express=require('express');

//创建空路由器
var router=express.Router();

//添加路由
//1.用户注册
router.post('/register',(req,res)=>{
	//获取post请求的数据
	var obj=req.body;
	//前提是服务器使用路由前已使用了第三方中间件body-parser
	//console.log(obj);
	//判断用户名是否为空
	var $uname=obj.uname;
	if(!$uname){
		res.send({code:401,msg:'uname required'});
		//阻止继续往后执行
		return;
	}
	//验证密码、邮箱、手机、性别是否为空
	//非空验证可能在前台做，以下代码可按需舍弃
	var $upwd=obj.upwd;
	if(!$upwd){
		res.send({code:402,msg:'upwd required'});
		return;
	}
	var $birthday=obj.birthday;
	if(!$birthday){
		res.send({code:402,msg:'birthday required'});
		return;
	}
	var $phone=obj.phone;
	if(!$phone){
		res.send({code:404,msg:'phone required'});
		return;
	}
	var $email=obj.email;
	if(!$email){
		res.send({code:403,msg:'email required'});
		return;
	}
	var $sex=obj.sex;
	if(!$sex){
		res.send({code:405,msg:'sex required'});
		return;
	}
	//执行SQL语句，将注册的数据插入到xz_user数据表中，
	//成功响应 {code:200,msg:'register success'}
	pool.query('INSERT INTO user SET ?',
		[obj],
		(err,result)=>{
			if(err) throw err;
			if(result.affectedRows>0){//是否添加成功
				res.send("ok");
			}else{
				res.send(0);
			}
		});
	//res.send('注册成功');
});

//2.用户登录路由
//url: /login   method:post
//创建路由，获取请求的数据，验证数据是否为空
router.post('/login',(req,res)=>{
	var obj=req.body;
	//console.log(obj);
	//验证数据是否为空
	var $uname=obj.uname;
	var $upwd=obj.upwd;
	if(!$uname){
		res.send({code:401,msg:'uname required'});
		return;
	}
	if(!$upwd){
		res.send({code:402,msg:'upwd required'});
		return;
	}
	//执行SQL语句，查看是否登陆成功(使用用户名和密码两
	//个条件能查询到数据)同时查询匹配到用户名和密码
	pool.query('SELECT * FROM user WHERE uname=? AND upwd=?',
		[$uname,$upwd],
		(err,result)=>{//result此时为SQL语句查询到的结果数组
			if(err) throw err;
			//console.log(result);//result为查询结果的数组
			//判断查询的结果(数组）长度是否大于0
			//如果大于0，说明查询到数据，有这个用户登录成功
			if(result.length>0){
				res.send("ok");
			}
			else{
				res.send(0);
			}
		}
	)
});

// 3.用户检索路由
router.get('/detail',(req,res)=>{
	var obj=req.query;//获取get请求的数据
	var $uid=obj.uid;
	//判断要检索的数据是否为空(不存在)
	if(!$uid){
		res.send({code:401,msg:'uid required'});
		return;
	}

	//执行SQL语句，查看是否检索到数据
	pool.query('SELECT * FROM user WHERE uid=?',
		[$uid],
		(err,result)=>{
		if(err) throw err;
		//console.log(result);		 
		//如何判断是否检索到了用户
		//判断结果(数组)长度是否大于0
		if (result.length>0)
		{
			res.send(result);//响应查询到的用户对象
		}
		else{//没查询到，检索失败
			res.send(0);
		}
	});
});

//4.更改用户路由
router.post('/update',(req,res)=>{
	//获取修改的数据，验证是否为空
	var obj=req.body;
	var $uid=obj.uid;
	var $email=obj.email;
	var $phone=obj.phone;
	var $sex=obj.sex;
	var $uname=obj.uname;
	var $upwd=obj.upwd;
	var $birthday=obj.birthday;
	//非空验证可能在前台做
	if(!$birthday){
		res.send({code:401,msg:'birthday required'});
		return;
	}
	if(!$email){
		res.send({code:402,msg:'email required'});
		return;
	}
	if(!$phone){
		res.send({code:403,msg:'phone required'});
		return;
	}
	if(!$sex){
		res.send({code:404,msg:'sex required'});
		return;
	}
	if(!$uname){
		res.send({code:405,msg:'uname required'});
		return;
	}
	if(!$upwd){
		res.send({code:406,msg:'upwd required'});
		return;
	}//后台不需要非空验证时以上代码可舍弃

	//执行SQL语句，修改用户表中对应的数据
	pool.query('UPDATE user SET uname=?,upwd=?,birthday=?,phone=?,email=?,sex=? WHERE uid=?',
		[$uname,$upwd,$birthday,$phone,$email,$sex,$uid],
		(err,result)=>{
			if(err) throw err;
			//console.log(result);
			//判断是否修改成功
			if(result.affectedRows>0){
				res.send("ok");
			}
			else{
				res.send(0);
			}
	});
});

//5.用户列表路由
// method:get    url:/list
router.get('/list',(req,res)=>{
	var obj=req.query;
	//console.log(obj);
	//将数据转为数值型(整型)
	var $pno=parseInt(obj.pno);
	var $count=parseInt(obj.count);
	//如果页码和每页的数量为空，设置默认值
	if(!$pno){
		//如果页码为空，默认第1页
		$pno=1;
	}
	if(!$count){
		//如果每页的数量为空，默认显示3条记录
		$count=3;
	}
	//计算开始查询的值
	var start=($pno-1)*$count;
	//执行SQL语句，返回商品列表数据
	pool.query('SELECT * FROM user LIMIT ?,?',
		[start,$count],
		(err,result)=>{
			if(err) throw err;
			res.send(result);//JSON.stringify(result)
	});
});

//6.路由————删除用户
router.get('/delete',(req,res)=>{
	var obj=req.query;//获取数据
	var $uid=obj.uid;
	//验证编号是否为空
	if(!$uid){
		res.send({code:401,msg:'uid required'});
		return;
	}
	//执行SQL语句，删除uid对应的记录(数据)
	pool.query('DELETE FROM user WHERE uid=?',
		[$uid],
		(err,result)=>{
			if(err) throw err;
			//console.log(result);
			//判断是否删除成功
			if(result.affectedRows>0){
				res.send("ok");
			}
			else{
				res.send(0);
			}
	});
});

//导出路由器
module.exports=router;











